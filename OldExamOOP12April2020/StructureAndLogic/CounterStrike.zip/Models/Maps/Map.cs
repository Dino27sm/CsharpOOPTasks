﻿using CounterStrike.Models.Maps.Contracts;
using CounterStrike.Models.Players.Contracts;
using System.Collections.Generic;
using System;
using System.Linq;

namespace CounterStrike.Models.Maps
{
    public class Map : IMap
    {
        private List<IPlayer> terrorists;
        private List<IPlayer> counterTerrorists;

        public Map()
        {
            this.terrorists = new List<IPlayer>();
            this.counterTerrorists = new List<IPlayer>();
        }

        public string Start(ICollection<IPlayer> players)
        {
            this.terrorists = players.Where(p => p.GetType().Name == "Terrorist").ToList();
            this.counterTerrorists = players.Where(p => p.GetType().Name == "CounterTerrorist").ToList();
            //this.terrorists = players.Where(p => p is Terrorist).ToList();
            //this.counterTerrorists = players.Where(p => p is CounterTerrorist).ToList();

            while (this.terrorists.Any(x => x.IsAlive) && this.counterTerrorists.Any(y => y.IsAlive))
            {
                foreach (var terorist in this.terrorists)   //Terorists attack first
                {
                    foreach (var counterTerrorist in this.counterTerrorists)
                    {
                        if (terorist.IsAlive && counterTerrorist.IsAlive)
                            counterTerrorist.TakeDamage(terorist.Gun.Fire());
                    }                       //Here a terrorist attacks -> counterTerrorists take damage
                }

                foreach (var terorist in this.terrorists)   //CounterTerorists attack second
                {
                    foreach (var counterTerrorist in this.counterTerrorists)
                    {
                        if (terorist.IsAlive && counterTerrorist.IsAlive)
                            terorist.TakeDamage(counterTerrorist.Gun.Fire());
                    }                       //Here a counterTerrorist attacks -> Terrorists take damage
                }
            }
            if (this.terrorists.Any(x => x.IsAlive))
                return "Terrorist wins!";

            return "Counter Terrorist wins!";
        }
    }
}
