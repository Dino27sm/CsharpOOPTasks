﻿namespace _05.BirthdayCelebrations
{
    public interface IIdentifyable
    {
        public string Id { get; set; }
    }
}
