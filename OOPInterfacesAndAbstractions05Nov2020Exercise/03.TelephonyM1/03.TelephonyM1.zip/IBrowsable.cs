﻿namespace _03.TelephonyM1
{
    public interface IBrowsable : IDialable
    {
        public bool BrowseSites(string webSites);
    }
}
