﻿namespace _03.TelephonyM1
{
    public interface IDialable
    {
        public bool DialPhoneNumber(string phoneNumber);
    }
}
