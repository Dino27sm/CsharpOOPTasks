﻿namespace _07.MilitaryElite.Interfaces
{
    using _07.MilitaryElite.Enumerators;

    public interface ISpecialisedSoldier
    {
        CorpsEnumerator CorpsEnumerator { get; }
    }
}
