﻿namespace _07.MilitaryElite.Interfaces
{
    public interface ISpy
    {
        public int CodeNumber { get; set; }
    }
}
