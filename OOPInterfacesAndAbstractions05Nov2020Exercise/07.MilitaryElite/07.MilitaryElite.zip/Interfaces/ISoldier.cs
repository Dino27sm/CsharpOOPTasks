﻿namespace _07.MilitaryElite.Interfaces
{
    public interface ISoldier
    {
        public int Id { get; set; }
        public string FirsName { get; set; }
        public string LastName { get; set; }
    }
}
