﻿namespace _07.MilitaryElite.Enumerators
{
    public enum MissionStateEnum
    {
        inProgress = 1,
        Finished = 2
    }
}
