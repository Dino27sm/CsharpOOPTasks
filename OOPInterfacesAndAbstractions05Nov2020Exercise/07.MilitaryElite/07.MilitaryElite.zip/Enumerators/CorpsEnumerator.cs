﻿namespace _07.MilitaryElite.Enumerators
{
    public enum CorpsEnumerator
    {
        Airforces = 1,
        Marines = 2
    }
}
