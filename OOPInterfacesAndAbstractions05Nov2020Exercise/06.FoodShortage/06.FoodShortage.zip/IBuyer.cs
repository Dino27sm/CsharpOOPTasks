﻿namespace _06.FoodShortage
{
    public interface IBuyer
    {
        public int Food { get; set; }

        public int BuyFood();
    }
}
