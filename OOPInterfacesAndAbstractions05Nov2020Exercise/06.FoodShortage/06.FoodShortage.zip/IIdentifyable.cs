﻿namespace _06.FoodShortage
{
    public interface IIdentifyable
    {
        public string Id { get; set; }
    }
}
