﻿
namespace _04.BorderControl
{
    public interface IIdentifyable
    {
        public string Id { get; set; }
    }
}
