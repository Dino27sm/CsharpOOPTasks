﻿namespace _04.BorderControl
{
    public interface IRobotable : IIdentifyable
    {
        public string Model { get; set; }
    }
}
