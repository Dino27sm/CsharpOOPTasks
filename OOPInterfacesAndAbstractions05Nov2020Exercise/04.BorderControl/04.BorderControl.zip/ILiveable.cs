﻿namespace _04.BorderControl
{
    public interface ILiveable : IIdentifyable
    {
        public string Name { get; set; }
    }
}
