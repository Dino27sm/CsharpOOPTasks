﻿namespace PlayersAndMonsters
{
    using System;
    public class StartUp
    {
        public static void Main(string[] args)
        {
            Hero heroOne = new Hero("thisHero", 100);
            Console.WriteLine(heroOne);

            Wizard wizardOne = new Wizard("thisWizard", 80);
            Console.WriteLine(wizardOne);

            DarkWizard darkWizardOne = new DarkWizard("thisDarkWizard", 70);
            Console.WriteLine(darkWizardOne);

            MuseElf museElfOne = new MuseElf("thisMuseElf", 60);
            Console.WriteLine(museElfOne);

            Hero museElfTwo = new MuseElf("thisMuseElf-Two", 66);
            Console.WriteLine(museElfTwo);

            Hero bladeKnightOne = new BladeKnight("thisBladeKnight", 67);
            Console.WriteLine(bladeKnightOne);
        }
    }
}