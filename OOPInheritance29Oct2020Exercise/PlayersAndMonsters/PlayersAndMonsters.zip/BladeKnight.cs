﻿namespace PlayersAndMonsters
{
    public class BladeKnight : DarkKnight
    {
        public BladeKnight(string usernameBladeKnight, int levelBladeKnight)
            : base(usernameBladeKnight, levelBladeKnight)
        {

        }
    }
}
