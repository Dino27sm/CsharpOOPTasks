﻿namespace PlayersAndMonsters
{
    public class Knight : Hero
    {
        public Knight(string usernameKnight, int levelKnight)
            : base(usernameKnight, levelKnight)
        {

        }
    }
}
