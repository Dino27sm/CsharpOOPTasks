﻿namespace PlayersAndMonsters
{
    public class DarkKnight : Knight
    {
        public DarkKnight(string usernameDarkKnight, int levelDarkKnight)
            : base(usernameDarkKnight, levelDarkKnight)
        {

        }
    }
}
