﻿namespace Zoo
{
    public class StartUp
    {
        public static void Main(string[] args)
        {
            Bear bearOne = new Bear("BearName");
            Lizard lizardOne = new Lizard("LizardName");
            Mammal mammalOne = new Mammal("MammalName");

            System.Console.WriteLine(bearOne.Name);
            System.Console.WriteLine(lizardOne.Name);
            System.Console.WriteLine(mammalOne.Name);
        }
    }
}