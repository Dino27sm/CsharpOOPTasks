﻿namespace NeedForSpeed
{
    using System;
    public class StartUp
    {
        public static void Main(string[] args)
        {
            Motorcycle raceMotorOne = new RaceMotorcycle(200, 100);
            Console.WriteLine(raceMotorOne.Fuel);
            raceMotorOne.Drive(5.0);
            Console.WriteLine(raceMotorOne.Fuel);

            Console.WriteLine("---------------------------------------------");

            Motorcycle crossMotorOne = new CrossMotorcycle(200, 100);
            Console.WriteLine(crossMotorOne.Fuel);
            crossMotorOne.Drive(5.0);
            Console.WriteLine(crossMotorOne.Fuel);
        }
    }
}
