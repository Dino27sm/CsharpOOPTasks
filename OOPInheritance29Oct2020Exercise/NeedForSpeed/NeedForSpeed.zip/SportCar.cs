﻿namespace NeedForSpeed
{
    public class SportCar : Car
    {
        private double defaultFuelConsumption = 10;
        public SportCar(int horsePower, double fuel)
            : base(horsePower, fuel)
        {
        }

        public override double FuelConsumption 
        {
            get => this.defaultFuelConsumption; 
        }
        public override void Drive(double kilometers)
        {
            this.Fuel -= (this.FuelConsumption * kilometers);
        }
    }
}
